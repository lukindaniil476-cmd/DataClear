package com.example.dataclear

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private enum class RequestStatus(val label: String) {
    DRAFT("Черновик"), SENT("Отправлен"), WAITING("Ожидание ответа"),
    ACTION_REQUIRED("Нужно уточнение"), COMPLETED("Подтверждено"), REJECTED("Отказ")
}
private data class Service(val name: String, val category: String, val url: String)
private data class DeletionRequest(
    val id: String = UUID.randomUUID().toString(),
    val service: String,
    val category: String,
    val email: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: RequestStatus = RequestStatus.DRAFT
)

private val services = listOf(
    Service("Google", "Аккаунты и платформы", "https://myaccount.google.com/"),
    Service("Instagram", "Социальные сети", "https://help.instagram.com/"),
    Service("TikTok", "Социальные сети", "https://support.tiktok.com/"),
    Service("Facebook", "Социальные сети", "https://www.facebook.com/help/"),
    Service("Reddit", "Социальные сети", "https://support.reddithelp.com/"),
    Service("Amazon", "Интернет-магазины", "https://www.amazon.com/gp/help/customer/display.html"),
    Service("Steam", "Игровые сервисы", "https://help.steampowered.com/"),
    Service("Epic Games", "Игровые сервисы", "https://www.epicgames.com/help/"),
    Service("Другой сервис", "Другое", "https://www.google.com/search?q=official+privacy+request")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DataClearApp(
            openUrl = { url -> runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
        ) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DataClearApp(openUrl: (String) -> Unit) {
    val clipboard = LocalClipboardManager.current
    // In-memory demo storage: entries persist only while this app process is alive.
    // Replace with Room + encrypted local storage for a production release.
    val requests = remember { mutableStateListOf<DeletionRequest>() }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<DeletionRequest?>(null) }
    var filter by remember { mutableStateOf("Все") }
    val filters = listOf("Все", "Активные", "Завершённые")

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF2563EB),
            secondary = androidx.compose.ui.graphics.Color(0xFF0F766E),
            background = androidx.compose.ui.graphics.Color(0xFFF7F8FC),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("DataClear", fontWeight = FontWeight.Bold)
                            Text("Контроль персональных данных", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Добавить запрос")
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Твои данные — под контролем", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Создавай запросы на удаление персональных данных, не удаляя аккаунты. Пароли не нужны.")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SummaryChip("Всего: ${requests.size}")
                                SummaryChip("Активных: ${requests.count { it.status !in listOf(RequestStatus.COMPLETED, RequestStatus.REJECTED) }}")
                            }
                        }
                    }
                }
                item {
                    Text("Запросы", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        filters.forEachIndexed { index, label ->
                            SegmentedButton(
                                selected = filter == label,
                                onClick = { filter = label },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = filters.size)
                            ) { Text(label) }
                        }
                    }
                }
                val visible = requests.filter {
                    when (filter) {
                        "Активные" -> it.status !in listOf(RequestStatus.COMPLETED, RequestStatus.REJECTED)
                        "Завершённые" -> it.status in listOf(RequestStatus.COMPLETED, RequestStatus.REJECTED)
                        else -> true
                    }
                }
                if (visible.isEmpty()) {
                    item {
                        Card {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(36.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Пока нет запросов", fontWeight = FontWeight.SemiBold)
                                Text("Нажми «+», чтобы создать первый запрос.")
                            }
                        }
                    }
                } else {
                    items(visible, key = { it.id }) { request ->
                        RequestCard(
                            request = request,
                            onOpen = { selected = request },
                            onStatus = { newStatus ->
                                val i = requests.indexOfFirst { it.id == request.id }
                                if (i >= 0) requests[i] = requests[i].copy(status = newStatus)
                            },
                            onDelete = { requests.removeAll { it.id == request.id } }
                        )
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Важно о приватности", fontWeight = FontWeight.Bold)
                            Text("DataClear не входит в аккаунты и не удаляет данные автоматически. Запрос считается завершённым только после подтверждения сервиса.")
                            Text("Не отправляй пароли, коды входа или документы через приложение.")
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddRequestDialog(
                onDismiss = { showAdd = false },
                onCreate = { service, email, details ->
                    requests.add(0, DeletionRequest(
                        service = service.name, category = service.category,
                        email = email.trim(), details = details.trim()
                    ))
                    showAdd = false
                    selected = requests.firstOrNull()
                }
            )
        }
        selected?.let { request ->
            RequestDetailDialog(
                request = request,
                onDismiss = { selected = null },
                onCopy = { clipboard.setText(AnnotatedString(makeTemplate(request))) },
                onOpen = {
                    val service = services.find { it.name == request.service }
                    openUrl(service?.url ?: "https://www.google.com/search?q=official+privacy+request")
                },
                onStatus = { status ->
                    val i = requests.indexOfFirst { it.id == request.id }
                    if (i >= 0) {
                        requests[i] = requests[i].copy(status = status)
                        selected = requests[i]
                    }
                }
            )
        }
    }
}

@Composable
private fun SummaryChip(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f)) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun RequestCard(
    request: DeletionRequest,
    onOpen: () -> Unit,
    onStatus: (RequestStatus) -> Unit,
    onDelete: () -> Unit
) {
    Card(onClick = onOpen, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(request.service, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(request.category, style = MaterialTheme.typography.bodySmall)
                }
                StatusPill(request.status)
            }
            Text("Создан: ${formatDate(request.createdAt)}", style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onOpen) { Text("Открыть") }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить запись") }
            }
        }
    }
}

@Composable
private fun StatusPill(status: RequestStatus) {
    Surface(
        shape = RoundedCornerShape(50),
        color = when (status) {
            RequestStatus.COMPLETED -> MaterialTheme.colorScheme.tertiaryContainer
            RequestStatus.REJECTED -> MaterialTheme.colorScheme.errorContainer
            else -> MaterialTheme.colorScheme.secondaryContainer
        }
    ) {
        Text(status.label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddRequestDialog(
    onDismiss: () -> Unit,
    onCreate: (Service, String, String) -> Unit
) {
    var serviceName by remember { mutableStateOf(services.first().name) }
    var email by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("Прошу удалить мои персональные данные, которые не нужны для предоставления услуги или выполнения обязательных юридических требований. Мой аккаунт прошу сохранить активным.") }
    var expanded by remember { mutableStateOf(false) }
    val service = services.first { it.name == serviceName }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый запрос") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Выбери сервис и укажи только данные, необходимые для обращения.")
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = serviceName, onValueChange = {}, readOnly = true,
                        label = { Text("Сервис") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        services.forEach { option ->
                            DropdownMenuItem(text = { Text(option.name) }, onClick = {
                                serviceName = option.name; expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    value = email, onValueChange = { email = it },
                    label = { Text("Email аккаунта (необязательно)") },
                    supportingText = { Text("Не вводи пароль или код подтверждения.") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = details, onValueChange = { details = it },
                    label = { Text("Текст запроса") }, minLines = 4, maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onCreate(service, email, details) }, enabled = details.isNotBlank()) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun RequestDetailDialog(
    request: DeletionRequest,
    onDismiss: () -> Unit,
    onCopy: () -> Unit,
    onOpen: () -> Unit,
    onStatus: (RequestStatus) -> Unit
) {
    var statusExpanded by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(request.service) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Статус: ${request.status.label}", fontWeight = FontWeight.SemiBold)
                Text("Создан: ${formatDate(request.createdAt)}")
                Text("Email: ${request.email.ifBlank { "не указан" }}")
                Text("Текст запроса", fontWeight = FontWeight.SemiBold)
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                    SelectionContainer { Text(request.details, Modifier.padding(12.dp)) }
                }
                OutlinedButton(onClick = onCopy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("Копировать текст запроса")
                }
                Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("Открыть официальный раздел")
                }
                ExposedDropdownMenuBox(expanded = statusExpanded, onExpandedChange = { statusExpanded = !statusExpanded }) {
                    OutlinedTextField(
                        value = request.status.label, onValueChange = {}, readOnly = true,
                        label = { Text("Обновить статус") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(statusExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                        RequestStatus.entries.forEach { s ->
                            DropdownMenuItem(text = { Text(s.label) }, onClick = { onStatus(s); statusExpanded = false })
                        }
                    }
                }
                Text("Статус меняется вручную. Выбирай «Подтверждено» только после ответа сервиса.")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } }
    )
}

private fun makeTemplate(request: DeletionRequest): String = """
Здравствуйте!

Прошу удалить персональные данные, связанные с моей учётной записью ${request.email.ifBlank { "[укажите идентификатор аккаунта]" }}, которые не требуются для предоставления услуги или хранения по обязательным требованиям закона.

Важно: я НЕ прошу удалить мой аккаунт. Прошу сохранить его активным и сообщить:
1. Какие категории моих персональных данных вы обрабатываете;
2. Какие данные могут быть удалены или обезличены;
3. Если часть данных нельзя удалить — правовое основание и срок хранения;
4. Когда запрос будет выполнен.

Дополнительная информация: ${request.details}

Пожалуйста, подтвердите получение обращения и сообщите результат после проверки личности через ваш официальный процесс.

Спасибо.
""".trimIndent()

private fun formatDate(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(time))
