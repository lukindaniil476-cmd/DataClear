# DataClear — Android starter

DataClear helps you prepare and track requests to erase personal data while keeping accounts active.

## Included
- Jetpack Compose interface in Russian
- Local request list and status tracking
- Service categories: social networks, shops, gaming
- Editable request draft with copy-to-clipboard
- Opens official privacy/support pages in the browser
- No passwords, cookies, or authentication tokens are collected or stored

## Important limits
This is a runnable starter app, not a universal deletion integration. It does not claim that data was deleted. The user must send the request through the service's official process and update the status after receiving a response. Service URLs are general privacy/help entry points and should be checked before use. Actual API integrations require each provider's official API, approved OAuth scopes, and provider-specific implementation.

## Open in Android Studio
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Run on an Android 8.0+ emulator/device.

If Android Studio asks for a Gradle JDK, select its embedded JDK 17.

## Build the APK without a PC (using GitHub in your phone browser)

This repository includes `.github/workflows/build-apk.yml` for a cloud build. This environment does not have the Android SDK installed, so it cannot honestly provide a compiled APK directly.

1. In your phone browser, create a repository on GitHub.
2. Upload the project files from this ZIP to the repository, including the hidden `.github/workflows/build-apk.yml` file. If GitHub's mobile upload interface cannot upload the hidden folder, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow contents from this file.
3. Open the repository's **Actions** tab and select **Build DataClear APK**. Run the workflow if it has not started automatically.
4. When it finishes successfully, open the run and download the **DataClear-debug-apk** artifact. Extract it on your phone; the APK inside is `app-debug.apk`.
5. Tap the APK to install. Android may ask you to allow installs from that browser or file manager; enable that only for the app you are using to install it.

This produces a debug APK for personal testing, not a Play Store release. The app's deletion requests are prepared for you to send; it does not automatically delete data from third-party services.
